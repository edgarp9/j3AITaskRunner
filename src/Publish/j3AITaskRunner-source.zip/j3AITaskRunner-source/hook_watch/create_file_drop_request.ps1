$ErrorActionPreference = "Stop"

$watchDir = Join-Path -Path $PSScriptRoot -ChildPath "watch"
New-Item -ItemType Directory -Path $watchDir -Force | Out-Null

do {
    $firstDigit = Get-Random -Minimum 1 -Maximum 10
    $remainingDigits = -join (1..9 | ForEach-Object { Get-Random -Minimum 0 -Maximum 10 })
    $requestId = "$firstDigit$remainingDigits"
    $requestFile = Join-Path -Path $watchDir -ChildPath "$requestId.j3aitask.json"
    $tempFile = "$requestFile.tmp"
} while (Test-Path -LiteralPath $requestFile)

if (Test-Path -LiteralPath $tempFile) {
    Remove-Item -LiteralPath $tempFile -Force
}

$request = [ordered]@{
    schema = "j3aitaskrunner.file-drop.v1"
    request_id = $requestId
    commands = @(
        [ordered]@{
            type = "start_registered_jobs"
        }
    )
}

$json = $request | ConvertTo-Json -Depth 4
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($tempFile, $json + [Environment]::NewLine, $utf8NoBom)

Move-Item -LiteralPath $tempFile -Destination $requestFile -Force
Write-Output "Created `"$requestFile`""
