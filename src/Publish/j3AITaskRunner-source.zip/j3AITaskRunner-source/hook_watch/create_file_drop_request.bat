@echo off
setlocal

set "WATCH_DIR=%~dp0watch"

if not exist "%WATCH_DIR%" (
    mkdir "%WATCH_DIR%"
    if errorlevel 1 (
        echo Failed to create watch directory: "%WATCH_DIR%"
        exit /b 1
    )
)

:generate_request_id
set "REQUEST_ID="
for /f "usebackq delims=" %%I in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$first = Get-Random -Minimum 1 -Maximum 10; $rest = -join (1..9 | ForEach-Object { Get-Random -Minimum 0 -Maximum 10 }); Write-Output ($first.ToString() + $rest)"`) do set "REQUEST_ID=%%I"

if not defined REQUEST_ID (
    echo Failed to generate request_id.
    exit /b 1
)

set "REQUEST_FILE=%WATCH_DIR%\%REQUEST_ID%.j3aitask.json"
set "TEMP_FILE=%REQUEST_FILE%.tmp"

if exist "%REQUEST_FILE%" goto generate_request_id
if exist "%TEMP_FILE%" del /f /q "%TEMP_FILE%"

(
    echo {
    echo   "schema": "j3aitaskrunner.file-drop.v1",
    echo   "request_id": "%REQUEST_ID%",
    echo   "commands": [
    echo     {
    echo       "type": "start_registered_jobs"
    echo     }
    echo   ]
    echo }
) > "%TEMP_FILE%"

if errorlevel 1 (
    echo Failed to write request file: "%TEMP_FILE%"
    exit /b 1
)

move /y "%TEMP_FILE%" "%REQUEST_FILE%" >nul
if errorlevel 1 (
    echo Failed to publish request file: "%REQUEST_FILE%"
    exit /b 1
)

echo Created "%REQUEST_FILE%"
exit /b 0
